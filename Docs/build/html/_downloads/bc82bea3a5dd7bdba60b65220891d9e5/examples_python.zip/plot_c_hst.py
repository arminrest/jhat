"""
======
Hubble
======

Aligning HST images with JHAT.
"""
		
###############################################################
# Explain here what this example does
   
import jhat

print('Hello World!')